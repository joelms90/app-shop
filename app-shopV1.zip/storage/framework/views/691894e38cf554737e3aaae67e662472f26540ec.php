    <footer class="footer">
        <div class="container">
            <nav class="pull-left">
                <ul>
                    <li>
                        <a href="#">
                            Quieres agregar un producto
                        </a>
                    </li>
                    <li>
                        <a href="#">
                           Acerca de
                        </a>
                    </li>
                    <li>
                        <a href="#">
                           Asesoria personalizada
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Sugerencias
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="copyright pull-right">
                &copy; 2018
            </div>
        </div>
    </footer>