<?php $__env->startSection('title','Tienda Virtual'); ?>

<?php $__env->startSection('body-class','product-page'); ?>

<?php $__env->startSection('content'); ?>
        <div class="header header-filter" style="background-image: url('https://images.unsplash.com/photo-1423655156442-ccc11daa4e99?crop=entropy&dpr=2&fit=crop&fm=jpg&h=750&ixjsv=2.1.0&ixlib=rb-0.3.5&q=50&w=1450');">
        </div>

        <div class="main main-raised">
            <div class="container">

                <div class="section ">
                    <h2 class="title text-center ">Editar producto selecionado</h2>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <form method="post" action="<?php echo e(url('/admin/products/'.$product->id.'/edit')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group label-floating">
                                    <label class="control-label">Nombre del producto</label>
                                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name',$product->name)); ?>">
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="form-group label-floating">
                                    <label class="control-label">Código</label>
                                    <input type="text" class="form-control" name="code" value="<?php echo e(old('code',$product->code)); ?>">
                                </div>
                            </div>    

                            <div class="col-sm-3">
                                <div class="form-group label-floating">
                                    <label class="control-label">Precio del producto</label>
                                    <input type="number" step="0.01" class="form-control" name="price" value="<?php echo e(old('price',$product->price)); ?>">
                                </div>
                            </div>



                        </div> 


                        
                        <div class="row">
                             <div class="col-sm-6">
                            <textarea class="form-control" placeholder="Descripción larga del producto..." rows="5" name="long_description" ><?php echo e(old('long_description',$product->long_description)); ?></textarea>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group label-floating">
                                    <label class="control-label">Descripción corta </label>
                                    <input type="text " class="form-control " name="description" value="<?php echo e(old('description',$product->description)); ?>">
                                </div>
                            </div>  

                        </div> 

                        <div class="row">
                        <div class="col-sm-12 text-center"  >
                            <button class="btn btn-primary">Guardar Cambios</button>
                            <a href="<?php echo e(url('/admin/products')); ?>" class="btn btn-default">Cancelar</a>
                        </div> 
                        </div> 


    
                    </form>

                </div>

            </div>

        </div>

   <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>